import React from 'react';
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import App from './App.js';

describe('SecureDeploy Web Application Smoke Test', () => {
  beforeEach(() => {
    // Mock global fetch to prevent actual network calls during test
    vi.stubGlobal('fetch', vi.fn().mockImplementation(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
          status: 'ok',
          service: 'securedeploy-api',
          timestamp: new Date().toISOString(),
          uptime: 42,
        }),
      })
    ));
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('renders landing page with title and branding', async () => {
    render(<App />);
    expect(screen.getByText(/SecureDeploy/i)).toBeDefined();
    expect(screen.getByText(/Automated Security Governance/i)).toBeDefined();
    expect(screen.getByText(/Foundation Architecture/i)).toBeDefined();
  });
});
